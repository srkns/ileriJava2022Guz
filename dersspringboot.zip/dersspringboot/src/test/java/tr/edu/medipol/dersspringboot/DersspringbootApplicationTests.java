package tr.edu.medipol.dersspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DersspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
